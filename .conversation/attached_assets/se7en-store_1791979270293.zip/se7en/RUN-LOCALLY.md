# Run SE7EN locally

1. Install Node.js 20+ (https://nodejs.org).
2. Open a terminal in this folder and run:

   npm install
   npm run dev

3. Open the address it prints (usually http://localhost:8080 or http://localhost:5173).

Build for production: npm run build
